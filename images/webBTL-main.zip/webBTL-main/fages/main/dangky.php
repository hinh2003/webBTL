<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<div class="login-page">
<div class="form">
  <h3>Đăng Ký</h3>
  <form id="formdangky" class="login-form"  action="/moudles/xuly.php">
    <input type="text" placeholder="Tên đăng Nhập" name="ten" id="ten" />
    <input type="text" placeholder="Email"name="email" id="email"/>
    <input type="password" placeholder="password" name="password" id="password"/>
    <input type="password" placeholder="re-password" name="r-password" id="r-password"/>
    <input type="submit" name="dangky" id="rep">
    <p id="result"></p>
  </form>
</div>
</div>
<script src="/js/js.js"></script>
